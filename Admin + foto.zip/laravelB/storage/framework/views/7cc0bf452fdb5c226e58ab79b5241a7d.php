<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Title</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
  <header>
    
  </header>

  <main>
    <?php if($errors->any()): ?>
      <div style="color: red;">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="container mt-4">
      <?php if(session('status')): ?>
        <div class="alert alert-success">
          <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-header text-center font-weight-bold">
          Data Mahasiswa
        </div>
        <div class="card-body">
          <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="<?php echo e(url('save')); ?>"enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="nim">NIM</label>
              <input type="text" id="nim" name="nim" class="form-control form-control-sm" required>
            </div>
            <div class="form-group">
              <label for="nama">NAMA</label>
              <input type="text" id="nama" name="nama" class="form-control form-control-sm" required>
            </div>
            <div class="form-group">
              <label for="umur">UMUR</label>
              <input type="text" id="umur" name="umur" class="form-control form-control-sm" required>
            </div>
            <div class="form-group">
              <label for="alamat">ALAMAT</label>
              <textarea name="alamat" class="form-control form-control-sm" required></textarea>
            </div>
            <div class="form-group">
              <label for="email">EMAIL</label>
              <input type="text" id="email" name="email" class="form-control form-control-sm" required>
            </div>
            <div class="form-group">
              <label for="foto">FOTO</label>
              <input type="file" id="foto" name="foto" class="form-control form-control-sm" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </main>

  <footer>
    <!-- place footer here -->
  </footer>

  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pecorine/Kuliah/Framewok/laravelB/resources/views/create.blade.php ENDPATH**/ ?>