<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Data Mahasiswa</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

  <!-- Add a separate CSS file for styles -->
  <link rel="stylesheet" href="styles.css">
</head>

<body>
  <header>
    <!-- Place navbar here -->
  </header>

  <main>
    <div class="container">
      <h2 class="mt-5">Data Mahasiswa</h2>
      <table class="table table-bordered table-striped mt-4">
        <thead class="table-dark">
          <tr>
            <th>NIM</th>
            <th>Nama</th>
            <th>Umur</th>
            <th>Alamat</th>
            <th>Email</th>
            <th>Foto</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><?php echo e(htmlspecialchars($data['nim'])); ?></td>
            <td><?php echo e(htmlspecialchars($data['nama'])); ?></td>
            <td><?php echo e(htmlspecialchars($data['umur'])); ?></td>
            <td><?php echo e(htmlspecialchars($data['alamat'])); ?></td>
            <td><?php echo e(htmlspecialchars($data['email'])); ?></td>
            <td>
           <img src="<?php echo e(url('images/' . $filename)); ?>" width="200px" alt="<?php echo e($data['foto']); ?>" >

            </td>

          </tr>
        </tbody>
      </table>

      <div class="text-center">
        <a href="/read" class="btn btn-success mt-3">Tampilkan data</a>
      </div>
    </div>
  </main>

  <footer>
    <!-- Place footer here -->
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
    integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>

  <!-- Add your custom scripts or scripts for confirmation modals if needed -->
  <script src="scripts.js"></script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pecorine/Kuliah/Framewok/laravelB/resources/views/view.blade.php ENDPATH**/ ?>