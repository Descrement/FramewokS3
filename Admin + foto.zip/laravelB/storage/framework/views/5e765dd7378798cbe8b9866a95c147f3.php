<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
   <title>Title</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

   <!-- Add a separate CSS file for styles -->
   <link rel="stylesheet" href="styles.css">
   <style>
      /* Custom styles for the table */
      .custom-table th,
      .custom-table td {
         text-align: center;
      }

      .custom-table th {
         background-color: #343a40; /* Dark gray background for header */
         color: #fff; /* White text for header */
      }

      .custom-table tbody tr:nth-child(odd) {
         background-color: #f8f9fa; /* Light gray background for odd rows */
      }

      .custom-table tbody tr:hover {
         background-color: #e2e6ea; /* Hover effect for rows */
      }

      .btn-add a {
         text-decoration: none;
         color: #fff; /* White text for the "Tambah data" link */
      }

      .btn-add a:hover {
         color: #fff; /* Hover effect for the "Tambah data" link */
      }
   </style>
</head>

<body>
   <header>
      <!-- Place navbar here -->
   </header>

   <main>
      <div class="container mt-4 table-responsive">
         <?php if(session('pesan')): ?>
         <div class="alert alert-success">
            <?php echo e(session('pesan')); ?>

         </div>
         <?php endif; ?>

         <h2 class="text-center title-heading">Database</h2>
         <table class="table custom-table mt-4">
            <thead>
               <tr>
                  <th>NIM</th>
                  <th>Nama</th>
                  <th>Umur</th>
                  <th>Alamat</th>
                  <th>Email</th>
                  <th>Foto</th>
                  <th>Created_at</th>
                  <th>Actions</th>
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $dataAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td><?php echo e($mahasiswa['nim']); ?></td>
                  <td><?php echo e($mahasiswa['nama']); ?></td>
                  <td><?php echo e($mahasiswa['umur']); ?></td>
                  <td><?php echo e($mahasiswa['alamat']); ?></td>
                  <td><?php echo e($mahasiswa['email']); ?></td>
                  <td>
                     <img src="<?php echo e(url('images/' . $mahasiswa['foto'])); ?>" width="200px" alt="<?php echo e($mahasiswa['foto']); ?>" >
                  </td>
                  <td><?php echo e(date('Y-m-d H:i:s', strtotime($mahasiswa['created_at']))); ?></td>
                  <td>
                     <a href="<?php echo e(url('/update/' . $mahasiswa['nim'])); ?>"
                        class="btn btn-warning btn-action" onclick="return confirmUpdate()">Update</a>

                     <button type="button" class="btn btn-danger btn-action" data-bs-toggle="modal"
                        data-bs-target="#confirmDeleteModal">Hapus</button>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>

         <div class="btn-add">
            <a href="/create" class="btn btn-primary">Tambah data</a>
         </div>
      </div>
   </main>

   <footer>
      <!-- Place footer here -->
   </footer>

   <!-- Modal for Delete Confirmation -->
   <div class="modal" id="confirmDeleteModal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title">Confirmation</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               Are you sure you want to delete this NIM? <?php echo e($mahasiswa['nim']); ?>

            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
               <a href="<?php echo e(url('/delete/' . $mahasiswa['nim'])); ?>" class="btn btn-danger">Delete</a>
            </div>
         </div>
      </div>
   </div>

   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
      integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
      crossorigin="anonymous"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
      integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
      crossorigin="anonymous"></script>

   <!-- Add your custom scripts or scripts for confirmation modals if needed -->
   <script src="scripts.js"></script>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/pecorine/Kuliah/Framewok/laravelB/resources/views/read.blade.php ENDPATH**/ ?>