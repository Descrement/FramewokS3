<?php

namespace App\Http\Controllers;
use App\Models\mahasiswa;
use Illuminate\Http\Request;

class MahasiswaController extends Controller{
public function create()
    {
        return view('create');
    }


    public function update($nim)
    {
        $data = mahasiswa::find($nim); 
        if ($data) {

            return view('update', ['data' => $data]);
        } else {
            return redirect('/read');
        }
    }


    public function edit(Request $request)
    {
        // ddd($request);
        $data = mahasiswa::find($request->nim);
        $filename = round(microtime(true) * 1000).'-'.str_replace(' ','-',$request->file('foto')->getClientOriginalName());
        $request->file('foto')->move(public_path('images'), $filename);
        if ($data) {
            $data->nama = $request->nama; 
            $data->alamat = $request->alamat;
            $data->foto = $filename;
            $data->updated_at = date('Y-m-d H:i:s');
            $data->save();
            return redirect('/read')->with('pesan', 'Data dengan NIM :' . $request->nim . ' berhasil diupdate');
        } else {
            return redirect('/read')->with('pesan', 'Data tidak ditemukan/gagal update');
        }
    }


    public function save(Request $request) 
    {

        // ddd($request);
        $validateData = $request->validate([
            'nim'=> 'required|regex:/^G\d{3}.\d{2}.\d{4}$/|unique:mahasiswas,nim',
            'nama'=> 'required|string|max:25',
            'umur'=> 'required|integer|between:1,100',
            'alamat'=> 'required|min:6',
            'email'=> 'required|email',
            'foto' => 'required',
            'foto.*' => 'mimes:doc,docx,PDF,pdf,jpg,jpeg,png|max:5000',
        ]);
        // $foto = $request->file('foto');
        // $tujuan = 'images';
        // $foto->store($tujuan,$foto->getClientOriginalName());
        $filename = round(microtime(true) * 1000).'-'.str_replace(' ','-',$request->file('foto')->getClientOriginalName());
        $request->file('foto')->move(public_path('images'), $filename);

        $model = new mahasiswa();
        $model->insert([
            'nim' => $request->nim,
            'nama' => $request->nama,
            'umur' => $request->umur,
            'email'=>$request->email,
            'alamat' => $request->alamat,
            'foto'=>$filename,
            'created_at' => date("Y-m-d H:i:s")
        ]);

        return view('view', [
            'data' => $request->all(),
            'filename' => $filename,
        ]);
    }


    public function read()
    {
        $model = new mahasiswa();
        $dataAll = $model->all();
        return view('read', ['dataAll' => $dataAll]);
    }


    public function delete($nim)
    {
        $data = mahasiswa::find($nim);
        if ($data) {
            $data->delete();
        } else {
            return redirect('/read')->with('pesan', 'Data NIM : ' . $nim . ' tidak ditemukan');
        }


        return redirect('/read')->with('pesan', 'Data NIM:' . $nim . ' Berhasil dihapus');
    }


    public function tampilkan(Request $request)
    {
        $model = new mahasiswa();
        $filename = round(microtime(true) * 1000).'-'.str_replace(' ','-',$request->file('foto')->getClientOriginalName());

        $model->create([
            'nim' => $request->nim,
            'nama' => $request->nama,
            'alamat' => $request->alamat,
            'foto' => $request->foto,
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        $dataAll = $model->all();
        return view('tampil2', [
            'data' => $request->all(),
            'dataAll' => $dataAll,
            

        ]);
    }
}

